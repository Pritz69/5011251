package exercise_5_DecoratorPatternExample;

public interface Notifier {
    void send(String message);
}
