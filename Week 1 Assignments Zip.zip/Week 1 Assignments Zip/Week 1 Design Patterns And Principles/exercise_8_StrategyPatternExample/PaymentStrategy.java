package exercise_8_StrategyPatternExample;

public interface PaymentStrategy {
    void pay(double amount);
}