package exercise_9_CommandPatternExample;

public interface Command {
	void execute();
}
